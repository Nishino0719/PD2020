
#include "kion-htmlreport2.h"
// 配列で渡された気温の日較差を求めて返す
double kion_nitikakusa(double max, double min){
    return max-min;
}