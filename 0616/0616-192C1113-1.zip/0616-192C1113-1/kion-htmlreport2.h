// 日較差を返す
double kion_nitikakusa(double max,double min);