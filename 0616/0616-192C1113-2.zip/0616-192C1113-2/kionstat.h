/* 配列で渡された気温の平均値を求めて返す */
double kion_heikin(double array[], int size);

/* 配列で渡された気温の最大値を求めて返す */
double kion_max(double array[], int size);

/* 配列で渡された気温の最小値を求めて返す */
double kion_min(double array[], int size);